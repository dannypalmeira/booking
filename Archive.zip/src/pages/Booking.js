import React from "react";


export default function BookingPage() {
    return (
    <h1>The Booking Page</h1>
    );
}